 <?php

 class Controller 
 {
      //kita selesaikan nanti
 }