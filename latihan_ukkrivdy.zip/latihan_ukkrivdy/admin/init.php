<?php 
//menghubungkan ke App.php yang mengatur URL
require_once 'core/App.php';

//menghubungkan ke Controller utama
require_once 'core/Controller.php';

//menghubungkan ke file konfigurasi
require_once 'config/Config.php';