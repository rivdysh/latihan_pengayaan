<?php

define('baseurl','http:/localhost/latihan_ukkrivdy/public');